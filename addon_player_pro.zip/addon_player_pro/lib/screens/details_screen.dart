import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import '../models/stremio_models.dart';
import '../services/addon_manager.dart';
import '../services/debrid_service.dart';
import 'player_screen.dart';

class DetailsScreen extends StatefulWidget {
  final MetaItem meta;
  const DetailsScreen({super.key, required this.meta});
  @override
  State<DetailsScreen> createState() => _DetailsScreenState();
}

class _DetailsScreenState extends State<DetailsScreen> {
  MetaDetails? _details;
  bool _loading = true;
  int? _season;

  @override
  void initState() {
    super.initState();
    AddonManager.instance.fetchMeta(widget.meta.type, widget.meta.id).then((d) {
      if (!mounted) return;
      setState(() {
        _details = d;
        _loading = false;
        final seasons = _seasons(d);
        if (seasons.isNotEmpty) {
          _season = seasons.firstWhere((s) => s > 0, orElse: () => seasons.first);
        }
      });
    });
  }

  List<int> _seasons(MetaDetails? d) =>
      (d?.videos.map((v) => v.season).toSet().toList() ?? <int>[])..sort();

  void _showStreams(String videoId, String title) {
    final meta = _details ?? widget.meta;
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => _StreamsSheet(
          type: meta.type, videoId: videoId, meta: meta, title: title),
    );
  }

  @override
  Widget build(BuildContext context) {
    final MetaItem meta = _details ?? widget.meta;
    final isSeries = meta.type == 'series';
    final videos = _details?.videos ?? [];
    final episodes = videos.where((v) => v.season == _season).toList()
      ..sort((a, b) => a.episode.compareTo(b.episode));

    return Scaffold(
      appBar: AppBar(title: Text(meta.name)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (meta.poster != null)
            Center(child: CachedNetworkImage(imageUrl: meta.poster!, height: 250)),
          const SizedBox(height: 12),
          if ((meta.description ?? '').isNotEmpty)
            Text(meta.description!, style: const TextStyle(color: Colors.grey)),
          const Divider(height: 30),
          if (_loading)
            const Center(child: CircularProgressIndicator())
          else if (!isSeries)
            FilledButton.icon(
              icon: const Icon(Icons.play_arrow),
              label: const Text('عرض روابط المشاهدة'),
              onPressed: () => _showStreams(meta.id, meta.name),
            )
          else if (videos.isEmpty)
            const Text('لا توجد حلقات متاحة لهذا المسلسل.')
          else ...[
            Row(children: [
              const Text('الموسم: '),
              const SizedBox(width: 8),
              DropdownButton<int>(
                value: _season,
                items: _seasons(_details)
                    .map((s) => DropdownMenuItem(
                        value: s, child: Text(s == 0 ? 'حلقات خاصة' : '$s')))
                    .toList(),
                onChanged: (v) => setState(() => _season = v),
              ),
            ]),
            ...episodes.map((v) => ListTile(
                  leading: CircleAvatar(child: Text('${v.episode}')),
                  title: Text(v.title),
                  trailing: const Icon(Icons.play_circle),
                  onTap: () => _showStreams(
                      v.id, '${meta.name} • S${v.season}E${v.episode}'),
                )),
          ],
        ],
      ),
    );
  }
}

class _StreamsSheet extends StatefulWidget {
  final String type, videoId, title;
  final MetaItem meta;
  const _StreamsSheet({
    required this.type,
    required this.videoId,
    required this.meta,
    required this.title,
  });
  @override
  State<_StreamsSheet> createState() => _StreamsSheetState();
}

class _StreamsSheetState extends State<_StreamsSheet> {
  late final Future<(List<StreamItem>, List<SubtitleItem>)> _fut = _load();
  bool _busy = false;

  Future<(List<StreamItem>, List<SubtitleItem>)> _load() async {
    final s = AddonManager.instance.fetchAllStreams(widget.type, widget.videoId);
    final sub = AddonManager.instance.fetchAllSubtitles(widget.type, widget.videoId);
    return (await s, await sub);
  }

  Future<void> _play(StreamItem st, List<SubtitleItem> subs) async {
    final messenger = ScaffoldMessenger.of(context);
    final nav = Navigator.of(context);
    setState(() => _busy = true);
    String? url = st.isDirectStream ? st.url : null;
    String? err;
    if (url == null && st.infoHash != null) {
      if (!DebridService.instance.hasAny) {
        err = 'هذا بث تورنت، يحتاج Real-Debrid (أضف التوكن من الإعدادات).';
      } else {
        url = await DebridService.instance.resolveTorrent(infoHash: st.infoHash!);
        if (url == null) err = 'التورنت غير مخزّن على Real-Debrid، جرّب رابطاً آخر.';
      }
    }
    if (!mounted) return;
    setState(() => _busy = false);
    if (url == null) {
      messenger.showSnackBar(SnackBar(content: Text(err ?? 'بث غير مدعوم')));
      return;
    }
    nav.pop();
    nav.push(MaterialPageRoute(
      builder: (_) => PlayerScreen(
        streamUrl: url!,
        playbackId: widget.videoId,
        title: widget.title,
        subtitles: subs,
        meta: widget.meta,
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: MediaQuery.of(context).size.height * 0.7,
      child: Column(children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: Text(widget.title,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        ),
        if (_busy) const LinearProgressIndicator(),
        Expanded(
          child: FutureBuilder<(List<StreamItem>, List<SubtitleItem>)>(
            future: _fut,
            builder: (c, s) {
              if (s.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }
              final streams = s.data?.$1 ?? [];
              final subs = s.data?.$2 ?? [];
              if (streams.isEmpty) {
                return const Center(
                    child: Text('لا توجد روابط. ثبّت إضافة بث من شاشة الإضافات.'));
              }
              return ListView.builder(
                itemCount: streams.length,
                itemBuilder: (c, i) {
                  final st = streams[i];
                  return ListTile(
                    enabled: !_busy,
                    leading: Icon(st.isDirectStream ? Icons.play_circle : Icons.cloud_download),
                    title: Text(st.name),
                    subtitle: Text(st.title, maxLines: 3, overflow: TextOverflow.ellipsis),
                    onTap: () => _play(st, subs),
                  );
                },
              );
            },
          ),
        ),
      ]),
    );
  }
}
