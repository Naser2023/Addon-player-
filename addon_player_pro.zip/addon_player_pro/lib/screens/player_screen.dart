import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:media_kit/media_kit.dart';
import 'package:media_kit_video/media_kit_video.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import '../models/stremio_models.dart';
import '../services/playback_service.dart';
import '../services/subtitle_service.dart';

class PlayerScreen extends StatefulWidget {
  final String streamUrl, playbackId, title;
  final List<SubtitleItem> subtitles;
  final MetaItem meta;
  const PlayerScreen({
    super.key,
    required this.streamUrl,
    required this.playbackId,
    required this.title,
    required this.subtitles,
    required this.meta,
  });
  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  late final Player player = Player();
  late final VideoController controller = VideoController(player);
  Timer? _saveTimer;

  @override
  void initState() {
    super.initState();
    WakelockPlus.enable();
    _init();
  }

  Future<void> _init() async {
    final pos = await PlaybackService.instance.getSavedPosition(widget.playbackId);
    await player.open(Media(widget.streamUrl,
        start: pos > 10 ? Duration(seconds: pos) : null));
    final ar = widget.subtitles
        .where((s) {
          final l = s.lang.toLowerCase();
          return l == 'ar' || l.startsWith('ara') || l.contains('arab');
        })
        .firstOrNull;
    if (ar != null) await _setSub(ar);
    _saveTimer = Timer.periodic(const Duration(seconds: 10), (_) => _save());
  }

  Future<void> _setSub(SubtitleItem s) async {
    final path = await SubtitleService.getPlayableSubtitle(s.url);
    await player.setSubtitleTrack(SubtitleTrack.uri(path));
  }

  void _save() {
    PlaybackService.instance.saveProgress(
      mediaId: widget.playbackId,
      meta: widget.meta,
      title: widget.title,
      position: player.state.position,
      duration: player.state.duration,
    );
  }

  @override
  void dispose() {
    _saveTimer?.cancel();
    _save();
    WakelockPlus.disable();
    player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black54,
        title: Text(widget.title, overflow: TextOverflow.ellipsis),
        actions: [
          PopupMenuButton<SubtitleItem?>(
            icon: const Icon(Icons.subtitles),
            tooltip: 'الترجمة',
            onSelected: (s) => s == null
                ? player.setSubtitleTrack(SubtitleTrack.no())
                : _setSub(s),
            itemBuilder: (_) => [
              const PopupMenuItem<SubtitleItem?>(value: null, child: Text('بدون ترجمة')),
              ...widget.subtitles.take(40).map((s) => PopupMenuItem<SubtitleItem?>(
                  value: s, child: Text('${s.lang} • ${s.addonName}'))),
            ],
          ),
        ],
      ),
      body: Center(
        // أزرار التحكم تبقى LTR
        child: Directionality(
          textDirection: TextDirection.ltr,
          child: Video(
            controller: controller,
            subtitleViewConfiguration: SubtitleViewConfiguration(
              style: GoogleFonts.cairo(
                fontSize: 32,
                color: Colors.white,
                backgroundColor: Colors.black54,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
