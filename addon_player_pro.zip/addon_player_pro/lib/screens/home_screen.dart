import 'package:flutter/material.dart';
import '../models/stremio_models.dart';
import '../services/addon_manager.dart';
import '../services/playback_service.dart';
import '../widgets/poster_card.dart';
import 'addons_screen.dart';
import 'details_screen.dart';
import 'search_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late Future<List<PlaybackHistoryItem>> _hist = PlaybackService.instance.getHistory();

  void _open(MetaItem m) => Navigator.push(
          context, MaterialPageRoute(builder: (_) => DetailsScreen(meta: m)))
      .then((_) => setState(() => _hist = PlaybackService.instance.getHistory()));

  static String _typeLabel(String t) =>
      t == 'movie' ? 'أفلام' : (t == 'series' ? 'مسلسلات' : t);

  @override
  Widget build(BuildContext context) {
    final catalogs = AddonManager.instance.homeCatalogs;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Addon Player Pro'),
        actions: [
          IconButton(
              icon: const Icon(Icons.search),
              onPressed: () => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const SearchScreen()))),
          IconButton(
              icon: const Icon(Icons.extension),
              onPressed: () => Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const AddonsScreen()))
                  .then((_) => setState(() {}))),
          IconButton(
              icon: const Icon(Icons.settings),
              onPressed: () => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const SettingsScreen()))),
        ],
      ),
      body: ListView(children: [
        FutureBuilder<List<PlaybackHistoryItem>>(
          future: _hist,
          builder: (c, s) {
            final list = s.data ?? [];
            if (list.isEmpty) return const SizedBox.shrink();
            return _Row(
              title: 'متابعة المشاهدة',
              count: list.length,
              builder: (i) => PosterCard(
                poster: list[i].poster,
                title: list[i].title,
                onTap: () => _open(MetaItem(
                    id: list[i].metaId,
                    type: list[i].type,
                    name: list[i].title,
                    poster: list[i].poster)),
              ),
            );
          },
        ),
        if (catalogs.isEmpty)
          const Padding(
            padding: EdgeInsets.all(24),
            child: Center(child: Text('لا توجد كتالوجات. ثبّت إضافة من شاشة الإضافات.')),
          ),
        for (final (a, c) in catalogs)
          _CatalogRow(
            key: ValueKey('${a.baseUrl}|${c.type}|${c.id}'),
            title: '${c.name} • ${_typeLabel(c.type)}',
            addon: a,
            catalog: c,
            onOpen: _open,
          ),
      ]),
    );
  }
}

class _Row extends StatelessWidget {
  final String title;
  final int count;
  final Widget Function(int) builder;
  const _Row({required this.title, required this.count, required this.builder});
  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(
        padding: const EdgeInsets.all(12),
        child: Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
      ),
      SizedBox(
        height: 180,
        child: ListView.builder(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 8),
          itemCount: count,
          itemBuilder: (c, i) =>
              Container(width: 115, margin: const EdgeInsets.all(4), child: builder(i)),
        ),
      ),
    ]);
  }
}

class _CatalogRow extends StatefulWidget {
  final String title;
  final AddonManifest addon;
  final CatalogDefinition catalog;
  final void Function(MetaItem) onOpen;
  const _CatalogRow({super.key, required this.title, required this.addon, required this.catalog, required this.onOpen});
  @override
  State<_CatalogRow> createState() => _CatalogRowState();
}

class _CatalogRowState extends State<_CatalogRow> {
  late final Future<List<MetaItem>> _f =
      AddonManager.instance.fetchCatalog(widget.addon, widget.catalog);
  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<MetaItem>>(
      future: _f,
      builder: (c, s) {
        final list = s.data ?? [];
        if (s.connectionState == ConnectionState.done && list.isEmpty) {
          return const SizedBox.shrink();
        }
        return _Row(
          title: widget.title,
          count: list.length,
          builder: (i) => PosterCard(
              poster: list[i].poster, title: list[i].name, onTap: () => widget.onOpen(list[i])),
        );
      },
    );
  }
}
