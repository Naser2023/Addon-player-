import 'package:flutter/material.dart';
import '../services/addon_manager.dart';

class AddonsScreen extends StatefulWidget {
  const AddonsScreen({super.key});
  @override
  State<AddonsScreen> createState() => _AddonsScreenState();
}

class _AddonsScreenState extends State<AddonsScreen> {
  final _c = TextEditingController();
  bool _busy = false;

  Future<void> _install() async {
    final url = _c.text.trim();
    if (url.isEmpty) return;
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('تأكيد التثبيت'),
        content: const Text(
            'الإضافات تُدار من أطراف خارجية. ثبّت فقط الإضافات التي تثق بمصدرها وتتأكد من قانونية محتواها.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('تثبيت')),
        ],
      ),
    );
    if (ok != true) return;
    setState(() => _busy = true);
    String msg;
    try {
      final m = await AddonManager.instance.installAddon(url);
      msg = 'تم تثبيت: ${m.name}';
      _c.clear();
    } catch (_) {
      msg = 'فشل التثبيت، تحقق من الرابط.';
    }
    if (!mounted) return;
    setState(() => _busy = false);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    final addons = AddonManager.instance.installedAddons;
    return Scaffold(
      appBar: AppBar(title: const Text('الإضافات')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          Row(children: [
            Expanded(
              child: TextField(
                controller: _c,
                textDirection: TextDirection.ltr,
                decoration: const InputDecoration(
                    labelText: 'رابط manifest.json أو stremio://',
                    border: OutlineInputBorder()),
              ),
            ),
            const SizedBox(width: 8),
            _busy
                ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2))
                : FilledButton(onPressed: _install, child: const Text('تثبيت')),
          ]),
          Expanded(
            child: ListView.builder(
              itemCount: addons.length,
              itemBuilder: (c, i) {
                final a = addons[i];
                return ListTile(
                  title: Text('${a.name} (${a.version})'),
                  subtitle: Text(
                    a.resources.map((r) => r.name).toSet().join(' • '),
                  ),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete),
                    onPressed: () async {
                      await AddonManager.instance.removeAddon(a);
                      setState(() {});
                    },
                  ),
                );
              },
            ),
          ),
        ]),
      ),
    );
  }
}
