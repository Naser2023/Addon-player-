import 'package:flutter/material.dart';
import '../services/debrid_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _rd = TextEditingController();
  @override
  void initState() {
    super.initState();
    _rd.text = DebridService.instance.rdToken ?? '';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          TextField(
            controller: _rd,
            obscureText: true,
            textDirection: TextDirection.ltr,
            decoration: const InputDecoration(
                labelText: 'Real-Debrid API Token', border: OutlineInputBorder()),
          ),
          const SizedBox(height: 12),
          FilledButton(
            onPressed: () async {
              await DebridService.instance.saveToken(_rd.text);
              if (!mounted) return;
              ScaffoldMessenger.of(context)
                  .showSnackBar(const SnackBar(content: Text('تم الحفظ')));
            },
            child: const Text('حفظ'),
          ),
        ]),
      ),
    );
  }
}
