import 'package:flutter/material.dart';
import '../models/stremio_models.dart';
import '../services/addon_manager.dart';
import '../widgets/poster_card.dart';
import 'details_screen.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});
  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  List<MetaItem> _res = [];
  bool _loading = false, _searched = false;

  Future<void> _search(String q) async {
    setState(() { _loading = true; _searched = true; });
    final list = await AddonManager.instance.search(q);
    if (!mounted) return;
    setState(() { _res = list; _loading = false; });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: TextField(
          autofocus: true,
          textInputAction: TextInputAction.search,
          decoration: const InputDecoration(
              hintText: 'ابحث عن فيلم أو مسلسل...', border: InputBorder.none),
          onSubmitted: _search,
        ),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : (_searched && _res.isEmpty)
              ? const Center(child: Text('لا نتائج'))
              : GridView.builder(
                  padding: const EdgeInsets.all(12),
                  gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                      maxCrossAxisExtent: 140,
                      childAspectRatio: 0.65,
                      crossAxisSpacing: 8,
                      mainAxisSpacing: 8),
                  itemCount: _res.length,
                  itemBuilder: (c, i) => PosterCard(
                    poster: _res[i].poster,
                    title: _res[i].name,
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => DetailsScreen(meta: _res[i]))),
                  ),
                ),
    );
  }
}
