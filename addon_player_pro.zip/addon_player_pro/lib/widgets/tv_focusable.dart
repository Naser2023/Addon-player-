import 'package:flutter/material.dart';

/// عنصر قابل للتركيز بالريموت (Android TV) وللمس.
class TvFocusable extends StatefulWidget {
  final Widget child;
  final VoidCallback onTap;
  const TvFocusable({super.key, required this.child, required this.onTap});
  @override
  State<TvFocusable> createState() => _TvFocusableState();
}

class _TvFocusableState extends State<TvFocusable> {
  bool _focused = false;
  @override
  Widget build(BuildContext context) {
    return FocusableActionDetector(
      onShowFocusHighlight: (v) => setState(() => _focused = v),
      actions: {
        ActivateIntent: CallbackAction<ActivateIntent>(onInvoke: (_) {
          widget.onTap();
          return null;
        }),
      },
      child: GestureDetector(
        onTap: widget.onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
                color: _focused ? Colors.deepPurpleAccent : Colors.transparent,
                width: 3),
          ),
          child: widget.child,
        ),
      ),
    );
  }
}
