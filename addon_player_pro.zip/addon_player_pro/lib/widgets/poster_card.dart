import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'tv_focusable.dart';

class PosterCard extends StatelessWidget {
  final String? poster;
  final String title;
  final VoidCallback onTap;
  const PosterCard({super.key, required this.poster, required this.title, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final fallback = Container(
      color: Colors.grey[850],
      padding: const EdgeInsets.all(6),
      alignment: Alignment.center,
      child: Text(title, textAlign: TextAlign.center, maxLines: 4, overflow: TextOverflow.ellipsis),
    );
    return TvFocusable(
      onTap: onTap,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(6),
        child: poster == null
            ? fallback
            : CachedNetworkImage(
                imageUrl: poster!,
                fit: BoxFit.cover,
                placeholder: (_, __) => Container(color: Colors.grey[850]),
                errorWidget: (_, __, ___) => fallback,
              ),
      ),
    );
  }
}
