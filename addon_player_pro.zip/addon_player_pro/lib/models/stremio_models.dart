List<String>? _strList(dynamic v) =>
    v is List ? v.map((e) => e.toString()).toList() : null;

class ResourceDef {
  final String name;
  final List<String>? types;
  final List<String>? idPrefixes;
  const ResourceDef(this.name, {this.types, this.idPrefixes});
}

class CatalogDefinition {
  final String type, id, name;
  final bool supportsSearch, hasRequiredExtra;
  const CatalogDefinition({
    required this.type,
    required this.id,
    required this.name,
    this.supportsSearch = false,
    this.hasRequiredExtra = false,
  });

  factory CatalogDefinition.fromJson(Map<String, dynamic> json) {
    final extra = (json['extra'] as List? ?? []).whereType<Map>().toList();
    final legacyReq = json['extraRequired'] as List? ?? [];
    final legacySup = json['extraSupported'] as List? ?? [];
    return CatalogDefinition(
      type: json['type']?.toString() ?? 'movie',
      id: json['id']?.toString() ?? '',
      name: json['name']?.toString() ?? json['id']?.toString() ?? '',
      supportsSearch: extra.any((e) => e['name'] == 'search') ||
          legacySup.contains('search') ||
          legacyReq.contains('search'),
      hasRequiredExtra:
          extra.any((e) => e['isRequired'] == true) || legacyReq.isNotEmpty,
    );
  }
}

class AddonManifest {
  final String id, name, version, description, baseUrl;
  final List<ResourceDef> resources;
  final List<String> types;
  final List<String>? idPrefixes;
  final List<CatalogDefinition> catalogs;

  AddonManifest({
    required this.id,
    required this.name,
    required this.version,
    required this.description,
    required this.baseUrl,
    required this.resources,
    required this.types,
    required this.idPrefixes,
    required this.catalogs,
  });

  factory AddonManifest.fromJson(Map<String, dynamic> json, String baseUrl) {
    final res = (json['resources'] as List? ?? [])
        .map<ResourceDef?>((r) {
          if (r is String) return ResourceDef(r);
          if (r is Map) {
            return ResourceDef(r['name'].toString(),
                types: _strList(r['types']),
                idPrefixes: _strList(r['idPrefixes']));
          }
          return null;
        })
        .whereType<ResourceDef>()
        .toList();
    final cats = (json['catalogs'] as List? ?? [])
        .whereType<Map>()
        .map((c) => CatalogDefinition.fromJson(Map<String, dynamic>.from(c)))
        .toList();
    return AddonManifest(
      id: json['id']?.toString() ?? baseUrl,
      name: json['name']?.toString() ?? 'إضافة',
      version: json['version']?.toString() ?? '1.0.0',
      description: json['description']?.toString() ?? '',
      baseUrl: baseUrl,
      resources: res,
      types: _strList(json['types']) ?? [],
      idPrefixes: _strList(json['idPrefixes']),
      catalogs: cats,
    );
  }

  /// توجيه الطلبات: هل تدعم الإضافة هذا المورد لهذا النوع والمعرّف؟
  bool supports(String resource, String type, String id) {
    for (final r in resources.where((r) => r.name == resource)) {
      final t = r.types ?? types;
      final p = r.idPrefixes ?? idPrefixes;
      if (t.isNotEmpty && !t.contains(type)) continue;
      if (p != null && p.isNotEmpty && !p.any((x) => id.startsWith(x))) continue;
      return true;
    }
    return false;
  }
}

class MetaItem {
  final String id, type, name;
  final String? poster, background, description, releaseInfo;
  MetaItem({
    required this.id,
    required this.type,
    required this.name,
    this.poster,
    this.background,
    this.description,
    this.releaseInfo,
  });

  factory MetaItem.fromJson(Map<String, dynamic> json, {String? type}) =>
      MetaItem(
        id: json['id']?.toString() ?? '',
        type: json['type']?.toString() ?? type ?? 'movie',
        name: json['name']?.toString() ?? 'بدون عنوان',
        poster: json['poster']?.toString(),
        background: json['background']?.toString(),
        description: json['description']?.toString(),
        releaseInfo: json['releaseInfo']?.toString(),
      );
}

class MetaVideo {
  final String id, title;
  final int season, episode;
  MetaVideo({
    required this.id,
    required this.title,
    required this.season,
    required this.episode,
  });

  factory MetaVideo.fromJson(Map<String, dynamic> json) => MetaVideo(
        id: json['id']?.toString() ?? '',
        title: (json['title'] ?? json['name'] ?? 'حلقة').toString(),
        season: int.tryParse(json['season']?.toString() ?? '') ?? 0,
        episode: int.tryParse(
                (json['episode'] ?? json['number'])?.toString() ?? '') ??
            0,
      );
}

class MetaDetails extends MetaItem {
  final List<MetaVideo> videos;
  MetaDetails({
    required super.id,
    required super.type,
    required super.name,
    super.poster,
    super.background,
    super.description,
    super.releaseInfo,
    this.videos = const [],
  });

  factory MetaDetails.fromJson(Map<String, dynamic> json) {
    final meta = Map<String, dynamic>.from(json['meta'] ?? json);
    final vids = (meta['videos'] as List? ?? [])
        .whereType<Map>()
        .map((v) => MetaVideo.fromJson(Map<String, dynamic>.from(v)))
        .where((v) => v.id.isNotEmpty)
        .toList();
    final base = MetaItem.fromJson(meta);
    return MetaDetails(
      id: base.id,
      type: base.type,
      name: base.name,
      poster: base.poster,
      background: base.background,
      description: base.description,
      releaseInfo: base.releaseInfo,
      videos: vids,
    );
  }
}

class StreamItem {
  final String name, title, addonName;
  final String? url, infoHash;
  StreamItem({
    required this.name,
    required this.title,
    this.url,
    this.infoHash,
    required this.addonName,
  });
  bool get isDirectStream => url != null && url!.startsWith('http');

  factory StreamItem.fromJson(Map<String, dynamic> json, String addonName) =>
      StreamItem(
        name: json['name']?.toString() ?? addonName,
        title: (json['title'] ?? json['description'] ?? 'بث').toString(),
        url: json['url']?.toString(),
        infoHash: json['infoHash']?.toString(),
        addonName: addonName,
      );
}

class SubtitleItem {
  final String id, lang, url, addonName;
  SubtitleItem({
    required this.id,
    required this.lang,
    required this.url,
    required this.addonName,
  });
  factory SubtitleItem.fromJson(Map<String, dynamic> json, String addonName) =>
      SubtitleItem(
        id: json['id']?.toString() ?? '',
        lang: json['lang']?.toString() ?? 'unknown',
        url: json['url']?.toString() ?? '',
        addonName: addonName,
      );
}
