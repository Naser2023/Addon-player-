import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../models/stremio_models.dart';

class AddonManager {
  static const _storageKey = 'installed_addon_urls_v3';
  static final AddonManager instance = AddonManager._();
  AddonManager._();

  final List<AddonManifest> installedAddons = [];
  final Map<String, Future<List<MetaItem>>> _catalogCache = {};

  static const List<String> defaultAddons = [
    'https://v3-cinemeta.strem.io/manifest.json',
    'https://opensubtitles-v3.strem.io/manifest.json',
  ];

  Future<List<String>> _loadUrls() async {
    final prefs = await SharedPreferences.getInstance();
    return List<String>.from(prefs.getStringList(_storageKey) ?? defaultAddons);
  }

  Future<void> _saveUrls(List<String> urls) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_storageKey, urls);
  }

  Future<void> init() async {
    final urls = await _loadUrls();
    final results = await Future.wait(urls.map((u) async {
      try {
        return await _fetchManifest(u);
      } catch (_) {
        return null;
      }
    }));
    installedAddons
      ..clear()
      ..addAll(results.whereType<AddonManifest>());
  }

  String _normalize(String raw) {
    var u = raw.trim().replaceFirst(RegExp(r'^stremio://'), 'https://');
    u = u.replaceAll(RegExp(r'/+$'), '');
    if (!u.endsWith('/manifest.json')) u = '$u/manifest.json';
    return u;
  }

  Future<Map<String, dynamic>?> _getJson(String url, {int seconds = 10}) async {
    try {
      final res =
          await http.get(Uri.parse(url)).timeout(Duration(seconds: seconds));
      if (res.statusCode != 200) return null;
      final d = jsonDecode(utf8.decode(res.bodyBytes));
      return d is Map<String, dynamic> ? d : null;
    } catch (_) {
      return null;
    }
  }

  Future<AddonManifest> _fetchManifest(String rawUrl) async {
    final url = _normalize(rawUrl);
    final json = await _getJson(url, seconds: 8);
    if (json == null) throw Exception('تعذر جلب manifest');
    return AddonManifest.fromJson(json, url.replaceFirst('/manifest.json', ''));
  }

  Future<AddonManifest> installAddon(String rawUrl) async {
    final url = _normalize(rawUrl);
    final manifest = await _fetchManifest(url);
    final urls = await _loadUrls();
    if (!urls.contains(url)) {
      urls.add(url);
      await _saveUrls(urls);
    }
    installedAddons.removeWhere((a) => a.id == manifest.id);
    installedAddons.add(manifest);
    return manifest;
  }

  Future<void> removeAddon(AddonManifest addon) async {
    final urls = await _loadUrls();
    urls.remove('${addon.baseUrl}/manifest.json');
    await _saveUrls(urls);
    installedAddons.removeWhere((a) => a.baseUrl == addon.baseUrl);
  }

  /// كتالوجات الصفحة الرئيسية (تُستبعد التي تتطلب معاملات إضافية)
  List<(AddonManifest, CatalogDefinition)> get homeCatalogs => [
        for (final a in installedAddons)
          for (final c in a.catalogs)
            if (!c.hasRequiredExtra) (a, c),
      ];

  Future<List<MetaItem>> fetchCatalog(AddonManifest a, CatalogDefinition c) {
    final key = '${a.baseUrl}|${c.type}|${c.id}';
    return _catalogCache.putIfAbsent(key, () async {
      final d = await _getJson('${a.baseUrl}/catalog/${c.type}/${c.id}.json');
      final list = (d?['metas'] as List? ?? [])
          .whereType<Map>()
          .map((m) => MetaItem.fromJson(Map<String, dynamic>.from(m), type: c.type))
          .toList();
      if (list.isEmpty) _catalogCache.remove(key);
      return list;
    });
  }

  Future<List<MetaItem>> search(String query) async {
    final q = Uri.encodeComponent(query.trim());
    if (q.isEmpty) return [];
    final futures = <Future<List<MetaItem>>>[];
    for (final a in installedAddons) {
      for (final c in a.catalogs.where((c) => c.supportsSearch)) {
        futures.add(() async {
          final d = await _getJson(
              '${a.baseUrl}/catalog/${c.type}/${c.id}/search=$q.json',
              seconds: 8);
          return (d?['metas'] as List? ?? [])
              .whereType<Map>()
              .map((m) =>
                  MetaItem.fromJson(Map<String, dynamic>.from(m), type: c.type))
              .toList();
        }());
      }
    }
    final seen = <String>{};
    return (await Future.wait(futures))
        .expand((e) => e)
        .where((m) => m.id.isNotEmpty && seen.add('${m.type}|${m.id}'))
        .toList();
  }

  Future<MetaDetails?> fetchMeta(String type, String id) async {
    final baseId = id.split(':')[0];
    for (final a in installedAddons.where((x) => x.supports('meta', type, baseId))) {
      final d = await _getJson('${a.baseUrl}/meta/$type/$baseId.json', seconds: 8);
      if (d != null && d['meta'] != null) return MetaDetails.fromJson(d);
    }
    return null;
  }

  Future<List<StreamItem>> fetchAllStreams(String type, String id) async {
    final futures =
        installedAddons.where((a) => a.supports('stream', type, id)).map((a) async {
      final d = await _getJson('${a.baseUrl}/stream/$type/$id.json');
      return (d?['streams'] as List? ?? [])
          .whereType<Map>()
          .map((s) => StreamItem.fromJson(Map<String, dynamic>.from(s), a.name))
          .where((s) => s.isDirectStream || s.infoHash != null)
          .toList();
    });
    return (await Future.wait(futures)).expand((e) => e).toList();
  }

  Future<List<SubtitleItem>> fetchAllSubtitles(String type, String id) async {
    final futures = installedAddons
        .where((a) => a.supports('subtitles', type, id))
        .map((a) async {
      final d = await _getJson('${a.baseUrl}/subtitles/$type/$id.json');
      return (d?['subtitles'] as List? ?? [])
          .whereType<Map>()
          .map((s) => SubtitleItem.fromJson(Map<String, dynamic>.from(s), a.name))
          .where((s) => s.url.isNotEmpty)
          .toList();
    });
    final all = (await Future.wait(futures)).expand((e) => e).toList();
    int rank(SubtitleItem s) {
      final l = s.lang.toLowerCase();
      return (l == 'ar' || l.startsWith('ara') || l.contains('arab')) ? 0 : 1;
    }

    all.sort((a, b) => rank(a).compareTo(rank(b)));
    return all;
  }
}
