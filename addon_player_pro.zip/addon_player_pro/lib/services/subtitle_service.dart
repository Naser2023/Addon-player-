import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:charset/charset.dart';
import 'package:path_provider/path_provider.dart';

class SubtitleService {
  /// يحمّل الترجمة ويحوّلها إلى UTF-8 (كثير من الترجمات العربية بترميز windows-1256).
  static Future<String> getPlayableSubtitle(String originalUrl) async {
    try {
      final res = await http
          .get(Uri.parse(originalUrl))
          .timeout(const Duration(seconds: 10));
      final bytes = res.bodyBytes;
      String text;
      try {
        text = utf8.decode(bytes, allowMalformed: false);
      } catch (_) {
        text = windows1256.decode(bytes);
      }
      final dir = await getTemporaryDirectory();
      final file =
          File('${dir.path}/sub_${DateTime.now().millisecondsSinceEpoch}.srt');
      await file.writeAsString(text, encoding: utf8);
      return file.path;
    } catch (_) {
      return originalUrl;
    }
  }
}
