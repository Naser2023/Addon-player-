import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class DebridService {
  static const _rdKey = 'real_debrid_api_token';
  static const _base = 'https://api.real-debrid.com/rest/1.0';
  static final DebridService instance = DebridService._();
  DebridService._();

  String? rdToken;

  Future<void> init() async {
    final p = await SharedPreferences.getInstance();
    rdToken = p.getString(_rdKey);
  }

  bool get hasAny => rdToken?.isNotEmpty ?? false;

  Future<void> saveToken(String? rd) async {
    final p = await SharedPreferences.getInstance();
    rdToken = rd?.trim();
    if (rdToken == null || rdToken!.isEmpty) {
      await p.remove(_rdKey);
    } else {
      await p.setString(_rdKey, rdToken!);
    }
  }

  /// يعمل فقط مع التورنتات المخزّنة مؤقتاً على Real-Debrid (Cached).
  Future<String?> resolveTorrent({required String infoHash}) async {
    if (!hasAny) return null;
    final h = {'Authorization': 'Bearer $rdToken'};
    String? id;
    try {
      final add = await http.post(Uri.parse('$_base/torrents/addMagnet'),
          headers: h, body: {'magnet': 'magnet:?xt=urn:btih:$infoHash'});
      if (add.statusCode != 201) return null;
      id = jsonDecode(add.body)['id'].toString();

      Future<Map<String, dynamic>> info() async {
        final r = await http.get(Uri.parse('$_base/torrents/info/$id'), headers: h);
        return Map<String, dynamic>.from(jsonDecode(r.body));
      }

      var i = await info();
      if (i['status'] == 'waiting_files_selection') {
        final files = (i['files'] as List)
            .map((f) => Map<String, dynamic>.from(f))
            .toList()
          ..sort((a, b) => (b['bytes'] as num).compareTo(a['bytes'] as num));
        await http.post(Uri.parse('$_base/torrents/selectFiles/$id'),
            headers: h, body: {'files': files.first['id'].toString()});
      }
      for (var n = 0; n < 8; n++) {
        i = await info();
        final s = i['status'];
        if (s == 'downloaded' ||
            ['magnet_error', 'error', 'virus', 'dead'].contains(s)) {
          break;
        }
        await Future.delayed(const Duration(seconds: 2));
      }
      if (i['status'] != 'downloaded') {
        await http.delete(Uri.parse('$_base/torrents/delete/$id'), headers: h);
        return null;
      }
      final links = i['links'] as List? ?? [];
      if (links.isEmpty) return null;
      final un = await http.post(Uri.parse('$_base/unrestrict/link'),
          headers: h, body: {'link': links.first.toString()});
      if (un.statusCode == 200) return jsonDecode(un.body)['download']?.toString();
    } catch (_) {}
    return null;
  }
}
