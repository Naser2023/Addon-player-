import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/stremio_models.dart';

class PlaybackHistoryItem {
  final String mediaId, metaId, title, type;
  final String? poster;
  final int positionSeconds, durationSeconds, updatedAt;
  PlaybackHistoryItem({
    required this.mediaId,
    required this.metaId,
    required this.title,
    required this.type,
    this.poster,
    required this.positionSeconds,
    required this.durationSeconds,
    required this.updatedAt,
  });

  Map<String, dynamic> toJson() => {
        'mediaId': mediaId,
        'metaId': metaId,
        'title': title,
        'poster': poster,
        'type': type,
        'positionSeconds': positionSeconds,
        'durationSeconds': durationSeconds,
        'updatedAt': updatedAt,
      };

  factory PlaybackHistoryItem.fromJson(Map<String, dynamic> j) =>
      PlaybackHistoryItem(
        mediaId: j['mediaId'] ?? '',
        metaId: j['metaId'] ?? j['mediaId'] ?? '',
        title: j['title'] ?? '',
        poster: j['poster'],
        type: j['type'] ?? 'movie',
        positionSeconds: j['positionSeconds'] ?? 0,
        durationSeconds: j['durationSeconds'] ?? 0,
        updatedAt: j['updatedAt'] ?? 0,
      );
}

class PlaybackService {
  static const _storageKey = 'playback_history_v3';
  static final PlaybackService instance = PlaybackService._();
  PlaybackService._();

  Future<List<PlaybackHistoryItem>> getHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_storageKey) ?? [];
    return raw.map((e) => PlaybackHistoryItem.fromJson(jsonDecode(e))).toList();
  }

  /// mediaId = معرّف الفيديو (فيلم أو حلقة)، meta = العمل الأصلي.
  Future<void> saveProgress({
    required String mediaId,
    required MetaItem meta,
    required String title,
    required Duration position,
    required Duration duration,
  }) async {
    if (duration.inSeconds < 30) return;
    final prefs = await SharedPreferences.getInstance();
    var list = await getHistory();
    list.removeWhere((i) => i.mediaId == mediaId);
    if (position.inSeconds / duration.inSeconds < 0.95) {
      list.insert(
          0,
          PlaybackHistoryItem(
            mediaId: mediaId,
            metaId: meta.id,
            title: title,
            poster: meta.poster,
            type: meta.type,
            positionSeconds: position.inSeconds,
            durationSeconds: duration.inSeconds,
            updatedAt: DateTime.now().millisecondsSinceEpoch,
          ));
    }
    if (list.length > 20) list = list.sublist(0, 20);
    await prefs.setStringList(
        _storageKey, list.map((e) => jsonEncode(e.toJson())).toList());
  }

  Future<int> getSavedPosition(String mediaId) async {
    final list = await getHistory();
    return list.where((e) => e.mediaId == mediaId).firstOrNull?.positionSeconds ?? 0;
  }
}
