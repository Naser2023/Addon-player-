# Addon Player Pro

## بناء الـ APK (الأسهل: GitHub)
1. أنشئ مستودعاً جديداً على github.com وارفع محتويات هذا المجلد (بما فيه `.github`).
2. افتح تبويب Actions وانتظر انتهاء "Build APK" (5-10 دقائق).
3. حمّل الملف من Releases ← latest ← `app-release.apk`.

## البناء محلياً
```
flutter create . --project-name addon_player_pro --org com.addonplayer --platforms=android
# أعد نسخ pubspec.yaml و lib/ من هذا المشروع إن استُبدلا
cp android_manifest/AndroidManifest.xml android/app/src/main/AndroidManifest.xml
flutter pub get && flutter build apk --release
```
